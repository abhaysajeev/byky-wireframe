# BYKY dashboard — drop-in patch

Transfers the approved dashboard design into the Django app **exactly** as designed.
The sidebar is already ported (`templates/sidebar/*` + `css/sidebar.css`) and is
untouched by this patch — labels and sub-labels keep coming from your existing
`vertical_menu.json`.

## 1. Copy these three files

| From this folder | To (relative to `django-version/full-version/`) |
|---|---|
| `src/assets/css/byky-dashboard.css` | `src/assets/css/byky-dashboard.css` *(new)* |
| `src/assets/js/byky-dashboard.js` | `src/assets/js/byky-dashboard.js` **(replaces the ApexCharts/Leaflet version)** |
| `apps/byky_core/templates/byky_dashboard.html` | `apps/byky_core/templates/byky_dashboard.html` **(replaces)** |

Then `python manage.py collectstatic` (or copy into `staticfiles/` the way you
normally do).

**Nothing in Python changes.** `views.py`, `seed.py`, `sales.py` and `geo.py` stay
as they are — the new JS reads the same `chart_data` payload through
`{{ chart_data|json_script:"byky-chart-data" }}`.

## 2. Add the mono face for vehicle codes

In `templates/layout/partials/styles.html`, next to the existing font links:

```html
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet" />
```

(Sora already arrives via `sidebar.css`.)

## 3. Optional — the 64px header from the design

`byky-dashboard.css` already restyles `#layout-navbar` to the design's 64px white
header. To also get the search pill and the name block, paste this inside
`templates/layout/partials/navbar/navbar.html`, immediately after the
`<div class="navbar-nav-right ...">` opening tag:

```html
<div class="bd-search">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9490bb" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.6-3.6"></path></svg>
  <span>Search vehicles, riders, stations…</span>
</div>
<div style="flex:1"></div>
```

and replace the avatar `<a class="nav-link dropdown-toggle ...">` inner markup with:

```html
<div class="bd-userblock">
  <div class="bd-avatar">AD</div>
  <div>
    <div class="bd-username">Admin</div>
    <div class="bd-userrole">Administrator</div>
  </div>
</div>
```

## What the JS draws (no vendor libraries)

* Monthly Sales sparkline + hover peak marker — `daily_revenue` / `daily_labels`
* Revenue Reports 12-month bars + hover peak/trough chips — `monthly_revenue` / `monthly_labels`
* Revenue by Emirate and by Category ranked bars — `revenue_emirate*` / `revenue_categor*`
* Fleet Deployment gauge (42 ticks, 270° sweep) — `deployment_pct`
* Station Network bubble map — `map_points` (real `geo.py` coordinates; the Kuwait
  point sits outside the UAE frame and is skipped, as it is on the design)
* Hero carousel (3 slides, 7s auto-advance, clickable dots)

## Removed dependencies

The dashboard page no longer loads ApexCharts, Swiper, Leaflet or DataTables. If no
other screen uses them you can drop those `{% block vendor_css %}` / `{% block vendor_js %}`
entries entirely; other screens that still include them are unaffected.

## Colour and type reference (same values as the design)

Ink `#1a1640` · muted `#6b6790` / `#9490bb` / `#a9a6c4` · hairline `#eeedf5` ·
page `#f4f5fa` · brand red `#d81f26`, deep `#c2141a`, tints `#ef767b` / `#f6b8bb` /
`#fdeced` · green `#1f9d63` / `#e9f8f0` · amber `#e08700` / `#fdf3e3` ·
blue `#3b6fd4` / `#eaf1fd`. Sora 400–700, tabular numerals on every figure;
card radius 16px, inner elements 6–12px.
